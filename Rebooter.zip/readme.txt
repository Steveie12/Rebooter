


To remove use a windows PE using a usb using rufus

the file that s making it reboot is C:\Users\your user\AppData\Roaming\Microsoft\Windows\StartMenu\Programs\Startup\  and the file is mssec.bat and delete it



- Reeps 2021


Roblox username : itsthereeps display name: DeadShoot
 Minecraft username : Steveie